import { ClientForm } from "@/features/clients/client-form";
export default function Page(){return <ClientForm/>}
